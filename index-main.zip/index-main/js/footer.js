const footer = document.querySelector(".footer");
footer.innerHTML = `
  <div class="bg-dark text-white p-4 mt-4">
    <div class="container">
      <p class="mb-0">&copy; 2024 Peter Good. All rights reserved.</p>
    </div>
  </div>
`;